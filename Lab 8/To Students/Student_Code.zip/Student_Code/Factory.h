#pragma once
#include "QSInterface.h"

using namespace std;

/*
	WARNING: It is expressly forbidden to modify any part of this document, including its name
*/
//=======================================================================================

class Factory
{
	public:
		static 	QSInterface * getQS();
};
//=======================================================================================
