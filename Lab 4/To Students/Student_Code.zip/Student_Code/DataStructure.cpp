/*
 * DataStructure.cpp
 *
 *  Created on: Feb 24, 2015
 *      Author: JasonT
 */

#include "DataStructure.h"

namespace std {

DataStructure::DataStructure() {

}

DataStructure::~DataStructure() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
