/*
 * ORDeque.cpp
 *
 *  Created on: Feb 25, 2015
 *      Author: Jason
 */

#include "ORDeque.h"

namespace std {

ORDeque::ORDeque() {
	// TODO Auto-generated constructor stub

}

ORDeque::~ORDeque() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
