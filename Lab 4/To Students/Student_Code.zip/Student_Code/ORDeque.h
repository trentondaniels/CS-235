/*
 * ORDeque.h
 *
 *  Created on: Feb 25, 2015
 *      Author: Jason
 */

#ifndef TO_STUDENTS_STUDENT_CODE_ORDEQUE_H_
#define TO_STUDENTS_STUDENT_CODE_ORDEQUE_H_

#include "Dequeue.h"

namespace std {

class ORDeque: public Dequeue {
public:
	ORDeque();
	virtual ~ORDeque();
};

} /* namespace std */

#endif /* TO_STUDENTS_STUDENT_CODE_ORDEQUE_H_ */
