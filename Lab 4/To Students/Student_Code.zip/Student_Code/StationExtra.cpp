/*
 * StationExtra.cpp
 *
 *  Created on: Feb 24, 2015
 *      Author: Jason
 */

#include "StationExtra.h"

namespace std {

StationExtra::StationExtra() {
	// TODO Auto-generated constructor stub

}

StationExtra::~StationExtra() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */
