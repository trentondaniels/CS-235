/*
 * StationExtra.h
 *
 *  Created on: Feb 24, 2015
 *      Author: Jason
 */

#ifndef TO_STUDENTS_STUDENT_CODE_STATIONEXTRA_H_
#define TO_STUDENTS_STUDENT_CODE_STATIONEXTRA_H_

#include "StationInterfaceExtra.h"

namespace std {

class StationExtra: public StationInterfaceExtra {
public:
	StationExtra();
	virtual ~StationExtra();
};

} /* namespace std */

#endif /* TO_STUDENTS_STUDENT_CODE_STATIONEXTRA_H_ */
