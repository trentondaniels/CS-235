/*
 * IRDeque.h
 *
 *  Created on: Feb 25, 2015
 *      Author: Jason
 */

#ifndef TO_STUDENTS_STUDENT_CODE_IRDEQUE_H_
#define TO_STUDENTS_STUDENT_CODE_IRDEQUE_H_

#include "Dequeue.h"

namespace std {

class IRDeque: public Dequeue {
public:
	IRDeque();
	virtual ~IRDeque();


};

} /* namespace std */

#endif /* TO_STUDENTS_STUDENT_CODE_IRDEQUE_H_ */
